* Title:            Package for the Acceleratable Channel interface UVC.
* Name:             channel
* Version:          0.1
* Created:          Sun Feb 15 11:02:24 2009 
* Support:          meade@cadence.com

* Description: 

This is the Channel UVC compatible with hardware acceleration
The Channel is a basic point to point protocol implemented in
UVM

* Directory structure:

This package contains the following directories: 

  sv/	    - All SystemVerilog source files
  tb/       - Verification Environment examples 
  docs/     - All package documentation
            
